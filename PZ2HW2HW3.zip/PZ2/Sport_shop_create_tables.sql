﻿/*
Задание 1. Создайте базу данных «Спортивный магазин».
Эта база данных должна содержать информацию о товарах,
продажах, сотрудниках, клиентах. Необходимо хранить
следующую информацию:
1. О товарах: название товара, вид товара (одежда, обувь,
и т.д.), количество товара в наличии, себестоимость, производитель, цена продажи
*/

use [master];
go
if db_id('SportShop') is not null
begin
	drop database [SportShop];
end
go
create database [SportShop];
go

use [SportShop];
go


create table [Products]
(
[Id] int not null identity(1, 1) primary key,
[Name] nvarchar(max) not null check([Name] <> N''),
[Type] nvarchar(max) not null check([Type] <> N''),
[Quantity] int not null default 0,
[CostPrice] money not null default 0,
[Manufacturer] nvarchar(max) not null check([Manufacturer] <> N''),
[SaleCost] money not null default 0
);

/*3. О сотрудниках: ФИО сотрудника, должность, дата приёма
на работу, пол, зарплата*/

create table [Positions]
(
[Id] int not null identity(1, 1) primary key,
[Position] nvarchar(max) not null check([Position] <> N'')
);

create table [Staff]
(
[Id] int not null identity(1, 1) primary key,
[Name] nvarchar(max) not null check([Name] <> N''),
[Surname] nvarchar(max) not null check([Surname] <> N''),
[Patronymic] nvarchar(max) not null check([Patronymic] <> N''),
[PositionId] int not null foreign key ([PositionId])
references [Positions] ([Id]),
[EmploymentDate] date not null check ([EmploymentDate] >= '2000-01-01'),
[Gender] bit not null,
[Salary] money not null check ([Salary] >= 0.0) default 0.0
);

/*4. О клиентах: ФИО клиента, email, контактный телефон,
пол, !история заказов, процент скидки, подписан ли на
почтовую рассылку.*/

create table [Clients]
(
[Id] int not null identity(1, 1) primary key,
[Email] nvarchar(max) not null check([Email] <> N''),
[Name] nvarchar(max) not null check([Name] <> N''),
[Surname] nvarchar(max) not null check([Surname] <> N''),
[Patronymic] nvarchar(max) not null check([Patronymic] <> N''),
[Phone] varchar(20) not null,
[Discount] float(12) not null check ([Discount] between 0.0 and 100.0) default 0,
[IsInMailingList] bit not null
);

/*2. О продажах: название проданного товара, цена продажи, количество, дата продажи, информация о продавце
(ФИО сотрудника, выполнившего продажу), информация
о покупателе (ФИО покупателя, если купил зарегистрированный покупатель)*/

create table [Orders]
(
[Id] int not null identity(1, 1) primary key,
[ProductsId] int not null foreign key ([ProductsId])
references [Products] ([Id]),
[Quantity] int not null default 0,
[Date] date not null check ([Date] >= '2020-01-01'),
[StaffId] int not null foreign key ([StaffId])
references [Staff] ([Id]),
[ClientId] int not null foreign key ([ClientId])
references [Clients] ([Id]),
);
create table [OrdersHistory]
(
[Id] int not null identity(1, 1) primary key,
[OrdersId] int not null foreign key ([OrdersId])
references [Orders] ([Id])
);

CREATE TABLE [History]
(
[Id] int not null identity(1, 1) primary key,
[ProductsId] int not null,
[Quantity] int not null default 0,
[Date] date not null check ([Date] >= '2020-01-01'),
[StaffId] int not null,
[ClientId] int not null
);

CREATE TABLE [Archive]
(
[Id] int not null identity(1, 1) primary key,
[ProductsId] int not null,
[Quantity] int not null default 0,
[Date] date not null check ([Date] >= '2020-01-01'),
[StaffId] int not null,
[ClientId] int not null
);

CREATE TABLE [LastUnit]
(
[Id] int not null identity(1, 1) primary key,
[ProductsId] int not null,
[Quantity] int not null default 0,
[Date] date not null check ([Date] >= '2020-01-01'),
[StaffId] int not null,
[ClientId] int not null
);
